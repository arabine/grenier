


#include <qlineedit.h>

class MyQLineEdit : public QLineEdit
{

public:
	MyQLineEdit(QWidget *parent, const char * name=0); 

};